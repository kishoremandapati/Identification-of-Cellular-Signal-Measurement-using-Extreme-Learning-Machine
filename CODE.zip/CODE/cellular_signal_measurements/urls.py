"""
URL configuration for cellular_signal_measurements project.
"""
from django.contrib import admin
from django.urls import path
from users import views
from cellular_signal_measurements import views as mainView
from admins import views as admins
from users import views as usr
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings


urlpatterns = [
    path('admin/', admin.site.urls),

    # ── Main / Auth ───────────────────────────────────────────
    path("",         mainView.index,      name="index"),
    path("index",    mainView.index,      name="index"),
    path("Login/",   mainView.Login,      name="Login"),
    path("LoginCheck/", mainView.LoginCheck, name="LoginCheck"),

    # ── Admin Views ───────────────────────────────────────────
    path('userDetails',   admins.RegisterUsersView, name='RegisterUsersView'),
    path('ActivUsers/',   admins.ActivaUsers,       name='activate_users'),
    path('DeleteUsers/',  admins.DeleteUsers,        name='delete_users'),
    path('adminhome',     admins.adminhome,          name='adminhome'),

    # ── User Views ────────────────────────────────────────────
    path("ViewDataset/",     usr.ViewDataset,         name="ViewDataset"),
    path('UserRegisterForm', usr.UserRegisterActions, name='UserRegisterForm'),
    path("UserHome/",        usr.UserHome,            name="UserHome"),
    path("index/",           usr.index,               name="index"),

    # ── ML : Train & Predict ──────────────────────────────────
    path('train_model/', views.train_model,    name='train_model'),
    path('predict/',     views.predict_signal, name='predict'),

    # ── Signal Tracking ───────────────────────────────────────
    path('update_signal_data/', views.update_signal_data,      name='update_signal_data'),
    path('get_live_data/',      views.get_live_tracking,        name='get_live_data'),
    path('get_best_network/',   views.get_best_network_in_area, name='get_best_network'),
    path('get_india_coverage/', views.get_india_cellular_coverage, name='get_india_coverage'),
    path('download_data/',      views.download_tracking_data,   name='download_data'),

    # ── Pages ─────────────────────────────────────────────────
    path('track_dashboard/', views.track_dashboard, name='track_dashboard'),

    # ── Debug (remove in production) ──────────────────────────
    path('debug_signals/',   views.debug_signal_data, name='debug_signals'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)