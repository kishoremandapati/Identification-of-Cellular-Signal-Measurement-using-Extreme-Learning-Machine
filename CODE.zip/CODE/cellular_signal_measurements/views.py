# from django.shortcuts import render, HttpResponse
# from django.contrib import messages
# from users.models import UserRegistrationModel

# from django.shortcuts import render


# def index(request):
#     return render(request, 'users/index.html')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 index.html', {})

# def AdminLogin(request):
#     return render(request, 'AdminLogin.html')

# def UserLogin(request):
#     return render(request, 'UserLogin.html')

                                                                                                                                                                                                                                                                                        
from django.shortcuts import render, HttpResponse
from django.contrib import messages
from users.models import UserRegistrationModel

def index(request):
    return render(request, 'index.html')                                                                                                                                                                                                                        

def Login(request):
    return render(request, 'users/login.html')

def LoginCheck(request):
    if request.method == 'POST':
        loginid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("Login ID =", loginid, "Password =", pswd)

        # Check for admin credentials
        if loginid == 'admin' and pswd == 'admin':
            return render(request, 'admins/AdminHome.html')

        # Check for normal user credentials
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            if check.status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                return render(request, 'users/UserHomePage.html', {})
            else:
                messages.success(request, 'Your Account is not activated yet.')
                return render(request, 'users/login.html', {})
        except Exception as e:
            # If getting UserRegistrationModel fails, it means invalid credentials
            pass

        messages.success(request, 'Invalid Login ID and password.')
    return render(request, 'users/login.html', {})
