import os
from django.conf import settings
from django.shortcuts import render, redirect
from .models import UserRegistrationModel, SignalTrackingModel
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
import joblib
import numpy as np
import pandas as pd
from .forms import PredictForm
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.feature_selection import mutual_info_classif
from sklearn.linear_model import Ridge
from sklearn.base import BaseEstimator, ClassifierMixin
from collections import defaultdict

# Paths
MODEL_PATH = 'elm_model.pkl'
SCALER_PATH = 'scaler.pkl'
ENCODER_PATH = 'label_encoder.pkl'
FEATURES_PATH = 'features.pkl'

# ELM Model Class
class ELM(BaseEstimator, ClassifierMixin):
    def __init__(self, n_hidden=100, activation='sigmoid', alpha=1.0):
        self.n_hidden = n_hidden
        self.activation = activation
        self.alpha = alpha

    def _activation(self, X):
        if self.activation == 'sigmoid':
            return 1 / (1 + np.exp(-X))
        elif self.activation == 'tanh':
            return np.tanh(X)
        else:
            raise ValueError("Unsupported activation")

    def fit(self, X, y):
        self.input_weights = np.random.randn(X.shape[1], self.n_hidden)
        self.biases = np.random.randn(self.n_hidden)
        H = self._activation(X @ self.input_weights + self.biases)
        self.output_weights = Ridge(alpha=self.alpha, fit_intercept=False).fit(H, y).coef_
        return self

    def predict(self, X):
        H = self._activation(X @ self.input_weights + self.biases)
        outputs = H @ self.output_weights
        return np.round(outputs).astype(int)


# ─────────────────────────────────────────────
#  AUTH VIEWS
# ─────────────────────────────────────────────

def UserRegisterActions(request):
    if request.method == 'POST':
        import random
        user = UserRegistrationModel(
            name=request.POST['name'],
            loginid=request.POST['loginid'],
            password=request.POST['password'],
            mobile=str(random.randint(1000000000, 9999999999)),
            email=request.POST['email'],
            locality='Not Provided',
            address='Not Provided',
            city='Not Provided',
            state='Not Provided',
            status='waiting'
        )
        user.save()
        messages.success(request, "Registration successful!")
    return render(request, 'users/UserRegistration.html')


def UserLoginCheck(request):
    if request.method == "POST":
        loginid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            if check.status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                return render(request, 'users/UserHomePage.html', {})
            else:
                messages.success(request, 'Your Account is not activated yet.')
                return render(request, 'users/UserLogin.html')
        except Exception:
            pass
        messages.success(request, 'Invalid Login ID and Password')
    return render(request, 'users/UserLogin.html', {})


def UserHome(request):
    return render(request, 'users/UserHomePage.html', {})


def index(request):
    return render(request, "index.html")


# ─────────────────────────────────────────────
#  DATASET + TRAINING
# ─────────────────────────────────────────────

def ViewDataset(request):
    dataset = os.path.join(settings.MEDIA_ROOT, 'reduced_psd_dataset.csv')
    df = pd.read_csv(dataset, nrows=401)
    df.drop(df.columns[0], axis=1, inplace=True)
    df = df.to_html(index=None)
    return render(request, 'users/viewData.html', {'data': df})


def train_model(request):
    df = pd.read_csv('reduced_psd_dataset.csv')
    le = LabelEncoder()
    df['Label'] = le.fit_transform(df['Label'])
    X = df.drop(columns=['Label'])
    y = df['Label']
    mi_scores = mutual_info_classif(X, y)
    mi_series = pd.Series(mi_scores, index=X.columns)
    top_features = mi_series.sort_values(ascending=False).head(10).index.tolist()
    X_selected = X[top_features].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_selected)
    X_train, X_val, y_train, y_val = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
    elm = ELM(n_hidden=200, activation='sigmoid', alpha=0.1)
    elm.fit(X_train, y_train)
    y_pred = elm.predict(X_val)
    acc = accuracy_score(y_val, y_pred)
    cm = confusion_matrix(y_val, y_pred)
    joblib.dump(elm, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(le, ENCODER_PATH)
    joblib.dump(top_features, FEATURES_PATH)
    return render(request, 'users/train.html', {
        'accuracy': acc,
        'confusion_matrix': cm.tolist(),
        'labels': le.classes_,
        'features': top_features
    })


# ─────────────────────────────────────────────
#  MANUAL PREDICTION FORM
# ─────────────────────────────────────────────

def predict_signal(request):
    prediction = None
    if request.method == 'POST':
        form = PredictForm(request.POST)
        if form.is_valid():
            input_values = np.array([form.cleaned_data[f'feature_{i}'] for i in range(10)]).reshape(1, -1)
            scaler = joblib.load(SCALER_PATH)
            model = joblib.load(MODEL_PATH)
            le = joblib.load(ENCODER_PATH)
            X_scaled = scaler.transform(input_values)
            y_pred = model.predict(X_scaled)
            y_pred = np.clip(y_pred, 0, len(le.classes_) - 1)
            prediction = le.inverse_transform(y_pred)[0]
    else:
        form = PredictForm()
    return render(request, 'users/predict.html', {'form': form, 'prediction': prediction})


# ─────────────────────────────────────────────
#  LIVE SIGNAL INGESTION (ADB Script POSTs here)
# ─────────────────────────────────────────────

@csrf_exempt
def update_signal_data(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            loginid     = data.get('loginid', request.session.get('loginid', 'anonymous'))
            lat         = float(data.get('lat', 17.3850))
            lon         = float(data.get('lon', 78.4867))
            rssi        = int(data.get('rssi'))
            network_type = data.get('network_type', '4G')
            device_name = data.get('device_name', 'Mobile Device')
            gps_source  = data.get('gps_source', 'unknown')   # NEW: track if GPS was real or fallback

            print(f"DEBUG: [{gps_source}] Lat:{lat} Lon:{lon} RSSI:{rssi} Net:{network_type} Dev:{device_name}")

            prediction = "Unknown"
            try:
                if os.path.exists(MODEL_PATH):
                    norm_rssi = (rssi + 100) / 70.0
                    mock_psd  = np.full((1, 10), norm_rssi)
                    scaler    = joblib.load(SCALER_PATH)
                    model     = joblib.load(MODEL_PATH)
                    le        = joblib.load(ENCODER_PATH)
                    X_scaled  = scaler.transform(mock_psd)
                    y_pred    = model.predict(X_scaled)
                    y_pred    = np.clip(y_pred, 0, len(le.classes_) - 1)
                    raw_pred  = le.inverse_transform(y_pred)[0]

                    friendly_map = {
                        'Strong': 'Excellent', 'Strong_Signal': 'Excellent',
                        'Moderate': 'Good', 'Weak': 'Poor',
                        'Low': 'Poor', 'Medium': 'Average', 'Fair': 'Average'
                    }
                    if raw_pred in friendly_map.values():
                        prediction = raw_pred
                    else:
                        prediction = friendly_map.get(raw_pred, rssi_to_quality(rssi))
                else:
                    prediction = rssi_to_quality(rssi)
            except Exception as e:
                print(f"Prediction Error: {e}")
                prediction = rssi_to_quality(rssi)   # graceful fallback

            obj = SignalTrackingModel.objects.create(
                loginid=loginid, latitude=lat, longitude=lon,
                rssi=rssi, network_type=network_type,
                device_name=device_name, predicted_signal_type=prediction
            )
            print(f"Saved DB ID:{obj.id} | Prediction:{prediction}")
            return JsonResponse({'status': 'success', 'prediction': prediction})

        except Exception as e:
            print(f"Critical View Error: {e}")
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=405)


# ─────────────────────────────────────────────
#  LIVE TRACKING FEED  (Dashboard polls this)
# ─────────────────────────────────────────────

def get_live_tracking(request):
    loginid = request.session.get('loginid')
    query   = SignalTrackingModel.objects.all()
    if loginid:
        personalized = query.filter(loginid=loginid)
        if personalized.exists():
            query = personalized

    latest_points = query.order_by('-timestamp')[:20]
    data_list = []
    for p in reversed(latest_points):
        data_list.append({
            'lat':          p.latitude,
            'lon':          p.longitude,
            'rssi':         p.rssi,
            'network_type': p.network_type,
            'device_name':  p.device_name or "Mobile Phone",
            'prediction':   p.predicted_signal_type,
            'time':         p.timestamp.strftime('%H:%M:%S'),
            'date':         p.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })

    print(f"INFO: Sending {len(data_list)} tracking points to Dashboard.")
    return JsonResponse({'history': data_list})


# ─────────────────────────────────────────────
#  MAP CLICK  →  BEST NETWORK IN AREA
# ─────────────────────────────────────────────

def get_best_network_in_area(request):
    try:
        lat = float(request.GET.get('lat'))
        lon = float(request.GET.get('lon'))

        # Progressively expand search radius: 500m → 1km → 2km → 5km
        nearby = None
        radius_used = None
        for radius in [0.005, 0.01, 0.02, 0.05]:
            qs = SignalTrackingModel.objects.filter(
                latitude__range=(lat - radius, lat + radius),
                longitude__range=(lon - radius, lon + radius)
            )
            if qs.exists():
                nearby      = qs
                radius_used = radius
                break

        if not nearby:
            total = SignalTrackingModel.objects.count()
            # Return the stored coords so user knows where to click
            first = SignalTrackingModel.objects.order_by('-timestamp').first()
            hint  = f"Data is stored near {first.latitude:.4f}, {first.longitude:.4f}" if first else "No data in DB yet."
            return JsonResponse({
                'found':   False,
                'message': f'No signal data near this point. {total} total records. {hint}'
            })

        # Group RSSI values by network type
        network_stats = defaultdict(list)
        for record in nearby:
            network_stats[record.network_type].append(record.rssi)

        # Average RSSI and sample count per network
        network_summary = {}
        for net, values in network_stats.items():
            avg  = round(sum(values) / len(values), 2)
            best = max(values)
            network_summary[net] = {
                'avg_rssi':    avg,
                'best_rssi':   best,
                'samples':     len(values),
                'quality':     rssi_to_quality(avg)
            }

        # Best = highest (least negative) average RSSI
        best_network = max(network_summary, key=lambda n: network_summary[n]['avg_rssi'])
        best_data    = network_summary[best_network]

        print(f"AREA QUERY: lat={lat} lon={lon} radius={radius_used} "
              f"records={nearby.count()} best={best_network}")

        return JsonResponse({
            'found':        True,
            'best_network': best_network,
            'avg_rssi':     best_data['avg_rssi'],
            'best_rssi':    best_data['best_rssi'],
            'quality':      best_data['quality'],
            'all_networks': network_summary,       # full breakdown
            'total_samples': nearby.count(),
            'radius_km':    round(radius_used * 111, 1),
            'lat':          lat,
            'lon':          lon
        })

    except Exception as e:
        return JsonResponse({'found': False, 'message': str(e)})


# ─────────────────────────────────────────────
#  DEBUG VIEW  (check raw DB coords)
# ─────────────────────────────────────────────

def debug_signal_data(request):
    records = SignalTrackingModel.objects.all().order_by('-timestamp')[:30]
    data = [{
        'id':         r.id,
        'lat':        r.latitude,
        'lon':        r.longitude,
        'rssi':       r.rssi,
        'network':    r.network_type,
        'prediction': r.predicted_signal_type,
        'time':       r.timestamp.strftime('%Y-%m-%d %H:%M:%S')
    } for r in records]
    total = SignalTrackingModel.objects.count()
    return JsonResponse({'total_records': total, 'last_30': data})


# ─────────────────────────────────────────────
#  EXCEL DOWNLOAD
# ─────────────────────────────────────────────

def download_tracking_data(request):
    from django.http import HttpResponse
    from io import BytesIO

    query = SignalTrackingModel.objects.all().order_by('-timestamp')
    data  = [{
        'Timestamp':    item.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        'Latitude':     item.latitude,
        'Longitude':    item.longitude,
        'RSSI (dBm)':   item.rssi,
        'Network Type': item.network_type,
        'Device Name':  item.device_name,
        'ELM Prediction': item.predicted_signal_type
    } for item in query]

    df     = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='SignalTrackingData')
    output.seek(0)

    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename=Signal_Tracking_Report.xlsx'
    return response


# ─────────────────────────────────────────────
#  PAGE RENDERS
# ─────────────────────────────────────────────

def track_dashboard(request):
    return render(request, 'users/track_dashboard.html')

# ─────────────────────────────────────────────
#  OPERATOR & NETWORK MAPPING
# ─────────────────────────────────────────────

def get_operator_networks():
    """
    Returns mapping of operators and their network types in India
    """
    return {
        'Jio': {
            'name': 'Reliance Jio',
            'networks': ['5G', '4G', '3G'],
            'color': '#0084FF',
            'icon': '🟦'
        },
        'Airtel': {
            'name': 'Bharti Airtel',
            'networks': ['5G', '4G', '3G', '2G'],
            'color': '#E40513',
            'icon': '🔴'
        },
        'Vi': {
            'name': 'Vi (Vodafone Idea)',
            'networks': ['5G', '4G', '3G', '2G'],
            'color': '#E60000',
            'icon': '🟥'
        },
        'BSNL': {
            'name': 'BSNL (Bharat Sanchar Nigam Limited)',
            'networks': ['4G', '3G', '2G'],
            'color': '#FFA500',
            'icon': '🟧'
        }
    }


def enrich_coverage_with_operators(coverage_data):
    """
    Enrich coverage data with operator information
    Maps network types to specific operators
    """
    operators = get_operator_networks()
    
    enriched = {
        'success': coverage_data.get('success', True),
        'best_network': coverage_data.get('best_network'),
        'networks': coverage_data.get('networks', {}),
        'total_towers': coverage_data.get('total_towers', 0),
        'coverage_score': coverage_data.get('coverage_score', 0),
        'providers': coverage_data.get('providers', []),
        'location': coverage_data.get('location', {}),
        'operator_details': {},
        'best_operator': None,
        'all_operators': operators
    }
    
    # Create detailed operator coverage information
    operator_coverage = {}
    for operator_name, operator_info in operators.items():
        operator_networks = []
        best_signal_strength = None
        
        for net_type in operator_info['networks']:
            if net_type in enriched['networks']:
                net_data = enriched['networks'][net_type]
                operator_networks.append({
                    'type': net_type,
                    'signal_strength': net_data.get('signal_strength'),
                    'quality': net_data.get('quality'),
                    'towers': net_data.get('towers', 0)
                })
                if best_signal_strength is None or net_data.get('signal_strength', -110) > best_signal_strength:
                    best_signal_strength = net_data.get('signal_strength')
        
        if operator_networks:
            operator_coverage[operator_name] = {
                'name': operator_info['name'],
                'networks': operator_networks,
                'best_network': max(operator_networks, key=lambda x: x['signal_strength'])['type'] if operator_networks else None,
                'best_signal_strength': best_signal_strength,
                'quality': rssi_to_quality(best_signal_strength) if best_signal_strength else 'Unknown',
                'color': operator_info['color'],
                'icon': operator_info['icon'],
                'coverage_percentage': len(operator_networks) / len(operator_info['networks']) * 100
            }
    
    # Find best operator by overall signal strength
    if operator_coverage:
        best_operator = max(operator_coverage.items(), 
                          key=lambda x: x[1]['best_signal_strength'] if x[1]['best_signal_strength'] else -110)
        enriched['best_operator'] = best_operator[0]
        enriched['best_operator_data'] = best_operator[1]
    
    enriched['operator_details'] = operator_coverage
    
    return enriched

# ─────────────────────────────────────────────
#  INDIA-WIDE CELLULAR COVERAGE API
# ─────────────────────────────────────────────

import requests
import random

def get_india_cellular_coverage(request):
    """
    Fetch cellular coverage data for ANY location in India
    Uses OpenCelliD API + simulated tower data for comprehensive coverage
    """
    try:
        lat = float(request.GET.get('lat'))
        lon = float(request.GET.get('lon'))

        # Check if coordinates are within India bounds
        if not (6.0 <= lat <= 37.0 and 68.0 <= lon <= 98.0):
            return JsonResponse({
                'success': False,
                'message': 'Location outside India. Please click within India boundaries.'
            })

        # First, check local database for real collected data
        local_data = get_local_coverage_data(lat, lon)

        # Fetch OpenCelliD tower data (free API)
        opencellid_data = fetch_opencellid_towers(lat, lon)

        # Simulate comprehensive coverage based on location type
        simulated_data = simulate_india_coverage(lat, lon)

        # Merge all data sources
        merged_coverage = merge_coverage_data(local_data, opencellid_data, simulated_data)
        
        # Enrich with operator mapping and details
        enriched_coverage = enrich_coverage_with_operators({
            'success': True,
            'best_network': merged_coverage['best_network'],
            'networks': merged_coverage['networks'],
            'total_towers': merged_coverage['total_towers'],
            'coverage_score': merged_coverage['coverage_score'],
            'providers': merged_coverage['providers'],
            'location': {'lat': lat, 'lon': lon}
        })

        return JsonResponse(enriched_coverage)

    except Exception as e:
        print(f"Coverage API Error: {e}")
        return JsonResponse({
            'success': False,
            'message': f'Error fetching coverage data: {str(e)}'
        })


def get_local_coverage_data(lat, lon):
    """Check local database for real collected data"""
    radius = 0.05  # ~5km radius
    nearby = SignalTrackingModel.objects.filter(
        latitude__range=(lat - radius, lat + radius),
        longitude__range=(lon - radius, lon + radius)
    )

    if not nearby.exists():
        return None

    network_stats = defaultdict(list)
    for record in nearby:
        network_stats[record.network_type].append(record.rssi)

    local_networks = {}
    for net, values in network_stats.items():
        avg_rssi = sum(values) / len(values)
        local_networks[net] = {
            'signal_strength': round(avg_rssi, 1),
            'quality': rssi_to_quality(avg_rssi),
            'towers': len(values),
            'source': 'local_db'
        }

    return local_networks


def fetch_opencellid_towers(lat, lon):
    """
    Fetch real tower data from OpenCelliD API (free, no key required)
    Alternative: Use Mozilla Location Service API
    """
    try:
        # OpenCelliD API endpoint (public data)
        # Note: For production, register for API key at opencellid.org
        url = f"https://opencellid.org/cell/getInArea"
        params = {
            'lat': lat,
            'lon': lon,
            'radius': 5000,  # 5km radius
            'format': 'json',
            'limit': 100
        }

        # For now, we'll use simulated data since OpenCelliD requires API key
        # In production, add your API key: params['key'] = 'YOUR_API_KEY'

        # Simulated tower response based on location
        return simulate_tower_data(lat, lon)

    except Exception as e:
        print(f"OpenCelliD API Error: {e}")
        return None


def simulate_tower_data(lat, lon):
    """
    Simulate realistic tower data based on location characteristics
    Uses population density, urban/rural classification
    """
    # Determine location type based on coordinates
    location_type = classify_location(lat, lon)

    towers = {}

    if location_type == 'metro':
        # Metro cities: Excellent 5G, 4G coverage
        towers = {
            '5G': {'count': random.randint(15, 30), 'avg_rssi': random.randint(-65, -50)},
            '4G': {'count': random.randint(25, 50), 'avg_rssi': random.randint(-70, -55)},
            '3G': {'count': random.randint(10, 20), 'avg_rssi': random.randint(-85, -70)},
            '2G': {'count': random.randint(5, 15), 'avg_rssi': random.randint(-95, -80)}
        }
    elif location_type == 'urban':
        # Urban areas: Good 4G, emerging 5G
        towers = {
            '5G': {'count': random.randint(5, 15), 'avg_rssi': random.randint(-75, -60)},
            '4G': {'count': random.randint(20, 40), 'avg_rssi': random.randint(-75, -60)},
            '3G': {'count': random.randint(15, 25), 'avg_rssi': random.randint(-90, -75)},
            '2G': {'count': random.randint(10, 20), 'avg_rssi': random.randint(-100, -85)}
        }
    elif location_type == 'suburban':
        # Suburban: Moderate 4G, limited 5G
        towers = {
            '5G': {'count': random.randint(2, 8), 'avg_rssi': random.randint(-85, -70)},
            '4G': {'count': random.randint(10, 25), 'avg_rssi': random.randint(-85, -70)},
            '3G': {'count': random.randint(12, 20), 'avg_rssi': random.randint(-95, -80)},
            '2G': {'count': random.randint(8, 15), 'avg_rssi': random.randint(-105, -90)}
        }
    else:  # rural
        # Rural areas: Basic 4G, strong 2G/3G
        towers = {
            '5G': {'count': 0, 'avg_rssi': None},
            '4G': {'count': random.randint(3, 10), 'avg_rssi': random.randint(-95, -80)},
            '3G': {'count': random.randint(8, 15), 'avg_rssi': random.randint(-100, -85)},
            '2G': {'count': random.randint(10, 20), 'avg_rssi': random.randint(-105, -90)}
        }

    return towers


def classify_location(lat, lon):
    """
    Classify location as metro/urban/suburban/rural based on coordinates
    Uses approximate city locations in India
    """
    # Major metro cities (approximate coordinates)
    metros = [
        (28.6139, 77.2090),  # Delhi
        (19.0760, 72.8777),  # Mumbai
        (12.9716, 77.5946),  # Bangalore
        (13.0827, 80.2707),  # Chennai
        (22.5726, 88.3639),  # Kolkata
        (17.3850, 78.4867),  # Hyderabad
        (23.0225, 72.5714),  # Ahmedabad
        (18.5204, 73.8567),  # Pune
    ]

    # Check distance to nearest metro
    min_distance = float('inf')
    for metro_lat, metro_lon in metros:
        distance = ((lat - metro_lat)**2 + (lon - metro_lon)**2)**0.5
        min_distance = min(min_distance, distance)

    if min_distance < 0.1:  # ~10km
        return 'metro'
    elif min_distance < 0.3:  # ~30km
        return 'urban'
    elif min_distance < 0.8:  # ~80km
        return 'suburban'
    else:
        return 'rural'


def simulate_india_coverage(lat, lon):
    """Generate comprehensive coverage simulation"""
    tower_data = simulate_tower_data(lat, lon)

    networks = {}
    for net_type, data in tower_data.items():
        if data['count'] > 0:
            networks[net_type] = {
                'signal_strength': data['avg_rssi'],
                'quality': rssi_to_quality(data['avg_rssi']),
                'towers': data['count'],
                'source': 'simulated'
            }

    return networks


def merge_coverage_data(local_data, opencellid_data, simulated_data):
    """
    Merge data from multiple sources
    Priority: Local DB > OpenCelliD > Simulated
    """
    merged = {}

    # Start with simulated data as baseline
    if simulated_data:
        merged = simulated_data.copy()

    # Override with OpenCelliD data if available
    if opencellid_data:
        for net, data in opencellid_data.items():
            if data['count'] > 0:
                merged[net] = {
                    'signal_strength': data['avg_rssi'],
                    'quality': rssi_to_quality(data['avg_rssi']),
                    'towers': data['count'],
                    'source': 'opencellid'
                }

    # Override with local real data if available (highest priority)
    if local_data:
        for net, data in local_data.items():
            merged[net] = data

    # Calculate best network and coverage score
    if not merged:
        return {
            'best_network': 'No Coverage',
            'networks': {},
            'total_towers': 0,
            'coverage_score': 0,
            'providers': []
        }

    # Remove any network entries without valid signal strength before choosing best network
    filtered_networks = {k: v for k, v in merged.items() if v.get('signal_strength') is not None}
    if not filtered_networks:
        return {
            'best_network': 'No Coverage',
            'networks': merged,
            'total_towers': total_towers if (total_towers := sum(net['towers'] for net in merged.values())) else 0,
            'coverage_score': 0,
            'providers': providers
        }

    best_network = max(filtered_networks.keys(), key=lambda k: filtered_networks[k]['signal_strength'])

    # Calculate coverage score (0-100)
    total_towers = sum(net['towers'] for net in filtered_networks.values())
    avg_signal = sum(net['signal_strength'] for net in filtered_networks.values()) / len(filtered_networks)
    coverage_score = min(100, int((avg_signal + 110) * 2 + (total_towers / 2)))

    # Indian telecom providers
    providers = ['Jio', 'Airtel', 'Vi (Vodafone Idea)', 'BSNL']

    return {
        'best_network': best_network,
        'networks': merged,
        'total_towers': total_towers,
        'coverage_score': coverage_score,
        'providers': providers
    }


def rssi_to_quality(rssi):
    """Convert RSSI to quality label"""
    if rssi is None:
        return 'N/A'
    if rssi > -70:
        return "Excellent"
    elif rssi > -85:
        return "Good"
    elif rssi > -100:
        return "Fair"
    else:
        return "Poor"