from django.db import models


class UserRegistrationModel(models.Model):
    name = models.CharField(max_length=100)
    loginid = models.CharField(unique=True, max_length=100)
    password = models.CharField(max_length=100)
    mobile = models.CharField(unique=True, max_length=10)
    email = models.EmailField(unique=True, max_length=100)
    locality = models.CharField(max_length=100)
    address = models.TextField(max_length=1000)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    status = models.CharField(max_length=100, default='waiting')

    def __str__(self):
        return self.loginid

    class Meta:
        db_table = 'user_registrations'


class SignalTrackingModel(models.Model):
    loginid = models.CharField(max_length=100)
    latitude = models.FloatField()
    longitude = models.FloatField()
    rssi = models.IntegerField()
    network_type = models.CharField(max_length=20, default='4G/LTE') # New field
    device_name = models.CharField(max_length=100, null=True)
    predicted_signal_type = models.CharField(max_length=100, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'signal_tracking'
